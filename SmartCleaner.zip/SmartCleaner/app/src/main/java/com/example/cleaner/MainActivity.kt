package com.example.cleaner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

// ---------- النماذج والتصنيف ----------
enum class Cat(val label: String, val exts: Set<String>) {
    IMAGES("الصور", setOf("jpg", "jpeg", "png", "webp", "heic", "gif")),
    VIDEOS("الفيديوهات", setOf("mp4", "mkv", "mov", "avi", "3gp")),
    DOCS("المستندات", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt")),
    AUDIO("الصوتيات", setOf("mp3", "m4a", "wav", "ogg", "opus")),
    APKS("ملفات APK", setOf("apk")),
    OTHER("أخرى", emptySet())
}

fun catOf(f: File): Cat {
    val e = f.extension.lowercase()
    return Cat.values().firstOrNull { e in it.exts } ?: Cat.OTHER
}

data class Item(val file: File, val size: Long)
data class ScanResult(val all: List<Item>, val dups: List<List<Item>>)

// ---------- المسح والحذف ----------
fun sha1(f: File): String = try {
    val md = MessageDigest.getInstance("SHA-1")
    FileInputStream(f).use { s ->
        val buf = ByteArray(65536)
        while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
    }
    md.digest().joinToString("") { "%02x".format(it) }
} catch (e: Exception) { "err:" + f.path }

fun scan(): ScanResult {
    val root = Environment.getExternalStorageDirectory()
    val items = root.walkTopDown()
        .onEnter { !it.name.startsWith(".") && !(it.parentFile == root && it.name == "Android") }
        .filter { it.isFile && !it.name.startsWith(".") }
        .map { Item(it, it.length()) }
        .toList()
    val dups = items.filter { it.size > 0 }
        .groupBy { it.size }.values.filter { it.size > 1 }
        .flatMap { g -> g.groupBy { sha1(it.file) }.values.filter { it.size > 1 } }
    return ScanResult(items, dups)
}

// الحذف الآمن: ينقل الملف إلى سلة مخفية بدل الحذف النهائي
fun moveToTrash(paths: List<String>) {
    val trash = File(Environment.getExternalStorageDirectory(), ".CleanerTrash").apply { mkdirs() }
    paths.forEach { p ->
        val f = File(p)
        val dest = File(trash, "${System.currentTimeMillis()}_${f.name}")
        if (!f.renameTo(dest)) { f.copyTo(dest, true); f.delete() }
    }
}

// ---------- الواجهة ----------
class MainActivity : ComponentActivity() {
    private val granted = mutableStateOf(false)

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onResume() { super.onResume(); granted.value = hasAccess() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { App(granted.value) { askAccess() } } }
            }
        }
    }
}

@Composable
fun App(granted: Boolean, onAsk: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var res by remember { mutableStateOf<ScanResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val sel = remember { mutableStateListOf<String>() }
    fun fmt(n: Long) = Formatter.formatFileSize(ctx, n)

    fun runScan() = scope.launch {
        busy = true; sel.clear()
        res = withContext(Dispatchers.IO) { scan() }
        busy = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("المنظّف الذكي", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        if (!granted) {
            Text("يحتاج التطبيق صلاحية الوصول لكل الملفات ليقدر يفحص وينظف.")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onAsk) { Text("منح الصلاحية") }
            return@Column
        }

        Button(onClick = { runScan() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (busy) "جارٍ الفحص..." else "ابدأ الفحص")
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

        val r = res ?: return@Column
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab) {
            listOf("نظرة عامة", "المكرر", "الكبير").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }

        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> LazyColumn(Modifier.padding(top = 8.dp)) {
                    item { Text("الإجمالي: ${r.all.size} ملف • ${fmt(r.all.sumOf { it.size })}", fontWeight = FontWeight.Bold) }
                    val byCat = r.all.groupBy { catOf(it.file) }
                    items(Cat.values().toList()) { c ->
                        val l = byCat[c].orEmpty()
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), Arrangement.SpaceBetween) {
                            Text(c.label)
                            Text("${l.size} • ${fmt(l.sumOf { it.size })}")
                        }
                        HorizontalDivider()
                    }
                    item {
                        val wasted = r.dups.sumOf { g -> g.drop(1).sumOf { it.size } }
                        Text("\nمساحة يمكن توفيرها من المكرر: ${fmt(wasted)}", fontWeight = FontWeight.Bold)
                    }
                }
                1 -> LazyColumn(Modifier.padding(top = 8.dp)) {
                    item {
                        OutlinedButton(onClick = {
                            sel.clear(); r.dups.forEach { g -> g.drop(1).forEach { sel.add(it.file.path) } }
                        }) { Text("حدد المكرر تلقائياً (تبقى نسخة واحدة)") }
                    }
                    r.dups.forEach { g ->
                        item { Text("${g.size} نسخ • ${fmt(g[0].size)} للملف", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
                        items(g) { FileRow(it, sel, ::fmt) }
                    }
                }
                else -> LazyColumn(Modifier.padding(top = 8.dp)) {
                    items(r.all.filter { it.size > 50L * 1024 * 1024 }.sortedByDescending { it.size }.take(100)) {
                        FileRow(it, sel, ::fmt)
                    }
                }
            }
        }

        if (sel.isNotEmpty()) {
            Button(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text("نقل ${sel.size} ملف إلى السلة")
            }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("تأكيد") },
        text = { Text("سيتم نقل ${sel.size} ملف إلى سلة مخفية (.CleanerTrash) ويمكنك استرجاعها من مدير الملفات.") },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                scope.launch {
                    withContext(Dispatchers.IO) { moveToTrash(sel.toList()) }
                    runScan()
                }
            }) { Text("نعم") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
    )
}

@Composable
fun FileRow(it: Item, sel: MutableList<String>, fmt: (Long) -> String) {
    val p = it.file.path
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = p in sel, onCheckedChange = { if (p in sel) sel.remove(p) else sel.add(p) })
        Column(Modifier.weight(1f)) {
            Text(it.file.name, maxLines = 1)
            Text(it.file.parent.orEmpty(), fontSize = 11.sp, maxLines = 1)
        }
        Text(fmt(it.size), fontSize = 12.sp)
    }
}
